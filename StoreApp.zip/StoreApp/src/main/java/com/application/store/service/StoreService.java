package com.application.store.service;
/**
 * 
 */
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import com.application.store.entity.Store;
import com.application.store.entity.User;
import com.application.store.repository.StoreRepository;
/**
 * 
 * @author ujjawal ranjan
 * This is service class for Store
 *
 */
@Service
public class StoreService {

	@Autowired
	private StoreRepository storeRepository;

	/**
	 * 
	 * @param id
	 * @return Store information
	 */
	public ResponseEntity<Store> getStore(long id) {

		Store store = storeRepository.findById(id).orElse(null);
		return ResponseEntity.ok().body(store);
	}

	/**
	 * 
	 * @param store - id, name , address
	 * @return newly created store entity
	 */
	public Store saveStore(Store store) {
		return storeRepository.save(store);
	}

	/**
	 * 
	 * @param storeId
	 * @returns store information along with assigned user
	 */
	public Store assignStoreToUser(long storeId) {
		int updatedRow=0;
		if(storeRepository.existsById(storeId)) {
			User user=getCurrentUser();

			updatedRow = storeRepository.assignStoreToUser(storeId, user.getUsername());
		}
		if(updatedRow>0) {
			Store store = storeRepository.findById(storeId).orElse(null);
			return store;
		}else {
			return null;
		}
	}
	
	/**
	 * 
	 * @returns current user
	 */
	public User getCurrentUser() {
		return new User(1l,"User1");
	}

}
