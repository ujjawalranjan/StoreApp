package com.application.store.controller;
/**
 * 
 */
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.application.store.entity.Store;
import com.application.store.service.StoreService;
/**
 * 
 * @author Ujjawal Ranjan
 * This class is controller class for the Store App.   
 *
 */
@RestController
public class StoreController {
	
	@Autowired
	private StoreService storeService;
	
	/**
	 * @URL http://localhost:8080/assignStore/{id}
	 * @param id
	 * @return store information
	 */
	@GetMapping("/store/{id}")
	public ResponseEntity<Store> getStore(@PathVariable(value="id")long id) {
		return storeService.getStore(id);
	}
	
	/**
	 * @URL http://localhost:8080/store
	 * @param store : id, name, address
	 * @return newly created Store entity
	 */
	@PostMapping("/store")
	public Store saveStore(@RequestBody Store store) {
		return storeService.saveStore(store);
	}
	
	/**
	 * 
	 * @param storeId
	 * @return Store entity with updated username
	 */
	@PutMapping("/assignStore/{storeId}")
	public Store assignStoreToUser(@PathVariable(value="storeId")long storeId){
		return storeService.assignStoreToUser(storeId);
	}


}
