package com.application.store.repository;
/**
 * 
 */
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;
import com.application.store.entity.Store;
/**
 * 
 * @author ujjawal ranjan
 * This is repository class for Store Entity
 *
 */
public interface StoreRepository extends JpaRepository<Store,Long>{
	
	@Transactional
	@Modifying
	@Query(value = "UPDATE store s set user_name =:userName where s.id = :storeId",nativeQuery = true)
	int assignStoreToUser(@Param("storeId") long storeId, @Param("userName") String userName);

}
